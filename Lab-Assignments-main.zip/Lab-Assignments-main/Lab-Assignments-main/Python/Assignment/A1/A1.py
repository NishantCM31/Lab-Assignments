# This code will raise an IndentationError
def faulty_function():
    print("This is line one")
      print("This is line two")  # Indentation Error here
