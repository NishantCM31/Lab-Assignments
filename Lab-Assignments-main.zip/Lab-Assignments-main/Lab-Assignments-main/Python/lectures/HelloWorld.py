print("Hello World")
print(1234)
print(True)