greet='hello'
print(greet[-5])
print(greet[-4])
print(greet[-3])
print(greet[-2])
print(greet[-1])
print(greet[0])