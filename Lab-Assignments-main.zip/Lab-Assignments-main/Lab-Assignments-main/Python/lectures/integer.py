c=0b1011000

d=(0b11011000)+c

print(0b11011000)

print(c)

print(d)

o=0o12

print(o)

h=0x12

print(h)

x='100'
print(type(x))

y=int(x)
print(type(y))