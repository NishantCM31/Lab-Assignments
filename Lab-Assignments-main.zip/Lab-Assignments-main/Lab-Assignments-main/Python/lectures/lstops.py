l1=[1,2,3]
l2=[4,5,6]
l3=l1+l2
print(l3)

a=[Hello]
print(a)