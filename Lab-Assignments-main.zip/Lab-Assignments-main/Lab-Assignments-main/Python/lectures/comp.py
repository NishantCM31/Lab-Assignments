a=6+4j
b=3+2j
print("a+2=",a+2)
print("a*2=",a*2)
print("a-2=",a-2)
print("a/2=",a/2)
print("a*2=",a*2)
print("a**2=",a**2)
print("a-b=",a-b)
print("a+b=",a+b)
    