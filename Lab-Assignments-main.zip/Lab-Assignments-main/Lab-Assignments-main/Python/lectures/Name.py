name="Ram"
print(name)
age=21
print(name,age)
print("Name: ",name,", Age: ",age)