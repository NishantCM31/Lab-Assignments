Name=input("Enter your name: ")
print("Name:",Name )

