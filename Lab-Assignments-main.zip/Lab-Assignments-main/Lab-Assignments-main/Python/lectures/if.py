if 10>5:
    print("10 is greater than 5")
if 20>10:
    print("20 is greater than 10")
else:
    print("10 is less than 5")