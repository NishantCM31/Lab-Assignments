a = int(input("Enter First Number: "))
b = int(input("Enter Second Number: "))
print("Number Before swap \n a = ",a,"b = ",b)
a,b=b,a
print("Number After swap \n a = ",a,"b = ",b)