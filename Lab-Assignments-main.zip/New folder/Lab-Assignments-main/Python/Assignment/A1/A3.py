while True:
    print("Select operation:")
    print("1. Add")
    print("2. Subtract")
    print("3. Multiply")
    print("4. Divide")
    print("5. Exit")
    switch = input("Enter choice (1/2/3/4/5): ")

    if switch == '5':
        print("Exiting the program.")
        break

    if switch in ('1', '2', '3', '4'):
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        if switch == '1':
            add = num1 + num2
            print(f"{num1} + {num2} = {add}")

        elif switch == '2':
            sub = num1 - num2
            print(f"{num1} - {num2} = {sub}")

        elif switch == '3':
            mul = num1 * num2
            print(f"{num1} * {num2} = {mul}")

        elif switch == '4':
            if num2 != 0:
                div = num1 / num2
                print(f"{num1} / {num2} = {div}")
            else:
                print("Error! Division by zero.")
    else:
        print("Invalid input")
